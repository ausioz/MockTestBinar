package com.example.binarmocktest_crudapp.domain.repository

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore

class LoginAuthRepo(private val application: Application) {

//    <editor-fold desc="firebase and firestore user data" defaultstate="collapsed">
//    user1 = 1@mocktest.com ; pass = 123456 ; role = admin
//    user2 = 2@mocktest.com ; pass = 123456 ; role = admin
//    user3 = 3@mocktest.com ; pass = 123456 ; role = admin
//    user4 = 4@mocktest.com ; pass = 123456 ; role = admin
//    user5 = 5@mocktest.com ; pass = 123456 ; role = admin
//    user6 = 6@mocktest.com ; pass = 123456 ; role = basic
//    user7 = 7@mocktest.com ; pass = 123456 ; role = basic
//     </editor-fold>

    val firebaseUserMutableLiveData: MutableLiveData<FirebaseUser?> = MutableLiveData()
    val userLoggedMutableLiveData: MutableLiveData<Boolean> = MutableLiveData()
    val userRoleMutableLiveData: MutableLiveData<String> = MutableLiveData()
    val currentUserMutableLiveData: MutableLiveData<String> = MutableLiveData()
    val currentNikMutableLiveData: MutableLiveData<String> = MutableLiveData()
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val fStore: FirebaseFirestore = FirebaseFirestore.getInstance()


    init {
        if (auth.currentUser != null) {
            firebaseUserMutableLiveData.postValue(auth.currentUser)
            userLoggedMutableLiveData.postValue(true)
            checkUserRole(auth.currentUser?.uid)
        }
    }

    fun register(email: String?, pass: String?) {
        auth.createUserWithEmailAndPassword(email!!, pass!!).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                firebaseUserMutableLiveData.postValue(auth.currentUser)
            } else {
                Toast.makeText(application, "Register Error", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun login(email: String?, pass: String?) {
        auth.signInWithEmailAndPassword(email!!, pass!!).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                firebaseUserMutableLiveData.postValue(auth.currentUser)
                checkUserRole(task.result.user?.uid)

            } else {
                Toast.makeText(
                    application,
                    "Login Error: Invalid mail and/or password",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }


    private fun checkUserRole(uid: String?) {
        val documentReference = fStore.collection("Users").document(uid!!)

        documentReference.get().addOnSuccessListener {
            if (it.getString("role") == "admin") {
                userRoleMutableLiveData.postValue("admin")
            } else {
                userRoleMutableLiveData.postValue("basic")
            }
            currentUserMutableLiveData.postValue(it.getString("nama"))
            currentNikMutableLiveData.postValue(it.getString("nik"))

        }
        documentReference.get().addOnFailureListener {
            Toast.makeText(application, "Role Error", Toast.LENGTH_SHORT).show()
        }
    }

    fun signOut() {
        auth.signOut()
        userLoggedMutableLiveData.postValue(false)
        userRoleMutableLiveData.postValue("")
    }

}
package com.example.binarmocktest_crudapp.viewmodel

import android.app.Application
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.binarmocktest_crudapp.domain.repository.LoginAuthRepo
import com.google.firebase.auth.FirebaseUser

class LoginViewModel(application: Application):ViewModel() {

    private val repository = LoginAuthRepo(application)
    private val userData = repository.firebaseUserMutableLiveData
    private val loggedStatus = repository.userLoggedMutableLiveData
    private val userRole = repository.userRoleMutableLiveData
    val currentUser = repository.currentUserMutableLiveData
    val currentNik = repository.currentNikMutableLiveData


    fun getUserData(): MutableLiveData<FirebaseUser?> {
        return userData
    }
    fun getLoggedStatus(): MutableLiveData<Boolean> {
        return loggedStatus
    }
    fun getUserRole(): MutableLiveData<String> {
        return userRole
    }

    fun register(email: String?, pass: String?) {
        repository.register(email, pass)
    }

    fun signIn(email: String?, pass: String?) {
        repository.login(email, pass)
    }

    fun signOut() {
        repository.signOut()
    }
}
package com.example.binarmocktest_crudapp.viewmodel

import android.app.Application
import android.util.Patterns
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.binarmocktest_crudapp.data.local.room.RecordDatabase
import com.example.binarmocktest_crudapp.model.RecordEntity
import kotlinx.coroutines.launch
import java.util.regex.Pattern

class RecordViewModel(var application: Application) : ViewModel() {
    private val db: RecordDatabase = RecordDatabase.getInstance(application)
    val recordHistory: LiveData<List<RecordEntity>> = db.recordDatabaseDao().getRecordHistory()


    fun recordData(record: RecordEntity) {
        viewModelScope.launch {
            db.recordDatabaseDao().insertRecord(record)
        }
    }

    fun updateRecord(record: RecordEntity) {
        viewModelScope.launch {
            db.recordDatabaseDao().updateRecord(record)
        }
    }

    fun deleteRecord(record: RecordEntity) {
        viewModelScope.launch {
            db.recordDatabaseDao().deleteRecord(record)
        }
    }

    fun getDateRecord():List<String> {
        return db.recordDatabaseDao().getDateByOrder().toList()
    }

}
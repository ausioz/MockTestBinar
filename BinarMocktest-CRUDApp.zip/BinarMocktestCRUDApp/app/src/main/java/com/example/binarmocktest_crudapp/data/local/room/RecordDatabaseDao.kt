package com.example.binarmocktest_crudapp.data.local.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RawQuery
import androidx.room.Update
import androidx.sqlite.db.SimpleSQLiteQuery
import com.example.binarmocktest_crudapp.model.RecordEntity

@Dao
interface RecordDatabaseDao {
    @Query("SELECT * FROM record")
    fun getRecordHistory(): LiveData<List<RecordEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertRecord(record: RecordEntity)

    @Update
    fun updateRecord(record:RecordEntity)

    @Delete
    fun deleteRecord(record: RecordEntity)

    @RawQuery
    fun rawQuery(theQuery: SimpleSQLiteQuery): List<String>
    fun getDateByOrder(): List<String> {
        return rawQuery(SimpleSQLiteQuery("SELECT tanggal FROM record ORDER BY tanggal DESC"))
    }
}

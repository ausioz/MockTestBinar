package com.example.binarmocktest_crudapp.history

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Parcelable
import android.util.Log
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.binarmocktest_crudapp.R
import com.example.binarmocktest_crudapp.databinding.ActivityHistoryBinding
import com.example.binarmocktest_crudapp.di.ViewModelFactory
import com.example.binarmocktest_crudapp.model.RecordEntity
import com.example.binarmocktest_crudapp.viewmodel.RecordViewModel

class HistoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHistoryBinding
    private lateinit var historyAdapter: HistoryAdapter
    private lateinit var recordsViewModel: RecordViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val currentRole = intent.getStringExtra("role")

        recordsViewModel =
            ViewModelProvider(this, ViewModelFactory(application))[RecordViewModel::class.java]

        recordsViewModel.recordHistory.observe(this, Observer {
            historyAdapter.setData(it)
        })

        binding.recycleView.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        historyAdapter = HistoryAdapter(this,
            object : HistoryAdapter.AdminListener {
                override fun isUserAdmin(): Boolean {
                    return currentRole == "admin"
                }
            }, onClickDelete = recordsViewModel::deleteRecord)

        Log.d("wkw",currentRole.toString())
        binding.recycleView.adapter = historyAdapter


    }


}
package com.example.binarmocktest_crudapp.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

@Entity(tableName = "record")
@Parcelize
data class RecordEntity (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id : Int,
    @ColumnInfo(name = "nik")
    var nik : String,
    @ColumnInfo(name = "nama")
    var nama : String,
    @ColumnInfo(name = "jumlahBarang")
    var jumlahBarang : String,
    @ColumnInfo(name = "pemasok")
    var pemasok : String,
    @ColumnInfo(name = "tanggal")
    var tanggal : String
): Parcelable

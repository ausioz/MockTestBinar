package com.example.binarmocktest_crudapp.history

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat.getColor
import androidx.recyclerview.widget.RecyclerView
import com.example.binarmocktest_crudapp.R
import com.example.binarmocktest_crudapp.databinding.ItemHistoryBinding
import com.example.binarmocktest_crudapp.history.edit.EditHistoryActivity
import com.example.binarmocktest_crudapp.model.RecordEntity


class HistoryAdapter(
    private val context : Context,
    private val callback : AdminListener,
    private val onClickDelete: (RecordEntity) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {
    private val records = arrayListOf<RecordEntity>()

    interface AdminListener {
        fun isUserAdmin():Boolean{
            return true
        }
    }

    inner class ViewHolder(
        private val binding: ItemHistoryBinding,
    ) : RecyclerView.ViewHolder(binding.root) {

        @SuppressLint("SetTextI18n")
        fun bind(recordEntity: RecordEntity) {

            binding.id.text = "Id Catatan: " + recordEntity.id.toString()
            binding.nik.text = "NIK: " + recordEntity.nik
            binding.nama.text = "Nama: " + recordEntity.nama
            binding.jumlahBarang.text = "Jumlah Barang: " + recordEntity.jumlahBarang
            binding.pemasok.text = "Pemasok: " + recordEntity.pemasok
            binding.tanggal.text = "Tanggal: " + recordEntity.tanggal

            Log.d("wkw",callback.isUserAdmin().toString())
            if (callback.isUserAdmin()){
                binding.delete.isClickable = true
                binding.delete.visibility = View.VISIBLE
                binding.edit.isClickable = true
                binding.edit.visibility = View.VISIBLE
            }
            else {
                binding.delete.isClickable = false
                binding.delete.visibility = View.GONE
                binding.edit.isClickable = false
                binding.edit.visibility = View.GONE
            }
            binding.delete.setOnClickListener {
                AlertDialog.Builder(context).setTitle("Hapus Catatan")
                    .setMessage("Apakah anda yakin dengan menghapus catatan?")
                    .setPositiveButton("Ya") { _, _ ->
                        onClickDelete(recordEntity)
                    }.setNegativeButton("Kembali") { _, _ -> }.show()
                }
            binding.edit.setOnClickListener {
                setListeners(
                    records[adapterPosition],
                    holder = ViewHolder(binding)
                )
            }
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemHistoryBinding.inflate(
                LayoutInflater.from(parent.context), parent, false
            )
        )
    }

    override fun getItemCount(): Int {
        return records.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(records[position])
    }

    fun setData(goods: List<RecordEntity>) {
        this.records.clear()
        this.records.addAll(goods)
        notifyDataSetChanged()
    }

    private fun setListeners(selectedRecord: RecordEntity, holder: HistoryAdapter.ViewHolder) {
        val intent = Intent(holder.itemView.context, EditHistoryActivity::class.java)
        // pass record to next activity
        intent.putExtra("record", selectedRecord)
        holder.itemView.context.startActivity(intent)
    }
}





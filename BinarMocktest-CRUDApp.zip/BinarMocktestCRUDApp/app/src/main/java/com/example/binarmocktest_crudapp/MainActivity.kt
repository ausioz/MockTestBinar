package com.example.binarmocktest_crudapp

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.binarmocktest_crudapp.databinding.ActivityMainBinding
import com.example.binarmocktest_crudapp.di.ViewModelFactory
import com.example.binarmocktest_crudapp.history.HistoryActivity
import com.example.binarmocktest_crudapp.history.HistoryAdapter
import com.example.binarmocktest_crudapp.history.edit.EditHistoryActivity
import com.example.binarmocktest_crudapp.login.LoginActivity
import com.example.binarmocktest_crudapp.record.RecordActivity
import com.example.binarmocktest_crudapp.viewmodel.LoginViewModel
import com.example.binarmocktest_crudapp.viewmodel.RecordViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var loginViewModel: LoginViewModel
    private var currentUserRole = ""
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loginViewModel =
            ViewModelProvider(this, ViewModelFactory(application))[LoginViewModel::class.java]


        loginViewModel.currentUser.observe(this, Observer {
            binding.welcomeTV.text = "Selamat Datang, $it"
        })


        loginViewModel.getUserRole().observe(this, Observer {
            if (it == "basic"){
                binding.catatBT.isClickable = false
                binding.catatBT.setBackgroundColor(getColor(androidx.appcompat.R.color.primary_dark_material_light))
                currentUserRole = "basic"
                toHistoryActivity()
            }
            if (it == "admin"){
                binding.catatBT.isClickable = true
                binding.catatBT.setBackgroundColor(getColor(R.color.base))
                currentUserRole = "admin"
                toHistoryActivity()
            }
        })
        binding.catatBT.setOnClickListener {
            startActivity(Intent(this, RecordActivity::class.java))
        }
        binding.signoutBT.setOnClickListener {
            loginViewModel.signOut()
            finish()
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }

    private fun toHistoryActivity(){
        binding.historyBT.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            // pass record to next activity
            intent.putExtra("role", currentUserRole)
            startActivity(intent)
        }
    }
}
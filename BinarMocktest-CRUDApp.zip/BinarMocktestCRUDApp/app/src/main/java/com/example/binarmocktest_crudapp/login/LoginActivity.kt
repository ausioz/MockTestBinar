package com.example.binarmocktest_crudapp.login

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.binarmocktest_crudapp.MainActivity
import com.example.binarmocktest_crudapp.databinding.ActivityLoginBinding
import com.example.binarmocktest_crudapp.di.ViewModelFactory
import com.example.binarmocktest_crudapp.viewmodel.LoginViewModel
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var loginViewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)


        loginViewModel =
            ViewModelProvider(this, ViewModelFactory(application))[LoginViewModel::class.java]

        loginViewModel.getUserData().observe(this, Observer {
            if (it != null) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        })

        binding.mailET.doAfterTextChanged {
            if (!isMailValid(binding.mailET.text.toString())){
                binding.mailET.error = "Format Email Salah"
            }
        }

        binding.loginBT.setOnClickListener {
            val mail = binding.mailET.text.toString()
            val pwd = binding.passwordET.text.toString()

            if (mail.isNotEmpty() && pwd.isNotEmpty()){
                loginViewModel.signIn(mail,pwd)
            }
            else{
                Toast.makeText(this, "Please input Mail and/or Password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun isMailValid(mail:String): Boolean {
        return if (mail.contains('@')) {
            Patterns.EMAIL_ADDRESS.matcher(mail).matches()
        } else {
            mail.isNotBlank()
        }
    }
}
package com.example.binarmocktest_crudapp.di

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.binarmocktest_crudapp.viewmodel.LoginViewModel
import com.example.binarmocktest_crudapp.viewmodel.RecordViewModel

class ViewModelFactory(private val application: Application): ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when(modelClass) {
            RecordViewModel::class.java -> RecordViewModel(application) as T
            LoginViewModel::class.java -> LoginViewModel(application) as T
            else -> {throw UnsupportedOperationException()}
        }
    }

}
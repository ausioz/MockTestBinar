package com.example.binarmocktest_crudapp.data.local.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.binarmocktest_crudapp.model.RecordEntity

@Database(
    entities =[RecordEntity::class],
    version = 1
)
abstract class RecordDatabase:RoomDatabase() {

    abstract fun recordDatabaseDao():RecordDatabaseDao

    companion object{
        private var INSTANCE: RecordDatabase? = null
        fun getInstance (context: Context) : RecordDatabase {
            if (INSTANCE ==null){
                synchronized(RecordDatabase::class){
                    INSTANCE = Room.databaseBuilder(
                        context,
                        RecordDatabase::class.java,"record.db",
                    )
                        .allowMainThreadQueries()
                        .build()
                }
            }
            return INSTANCE as RecordDatabase
        }

    }

}
package com.example.binarmocktest_crudapp.record

import android.icu.util.Calendar
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.binarmocktest_crudapp.R
import com.example.binarmocktest_crudapp.databinding.ActivityRecordBinding
import com.example.binarmocktest_crudapp.di.ViewModelFactory
import com.example.binarmocktest_crudapp.model.RecordEntity
import com.example.binarmocktest_crudapp.viewmodel.LoginViewModel
import com.example.binarmocktest_crudapp.viewmodel.RecordViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRecordBinding
    private lateinit var recordViewModel: RecordViewModel
    private lateinit var loginViewModel: LoginViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recordViewModel =
            ViewModelProvider(this, ViewModelFactory(application))[RecordViewModel::class.java]
        loginViewModel =
            ViewModelProvider(this, ViewModelFactory(application))[LoginViewModel::class.java]

        binding.tanggalET.doAfterTextChanged {
            if (isDateInputValid()) {
                binding.simpanBT.setBackgroundColor(getColor(R.color.base))
                binding.simpanBT.isClickable = true
            } else {
                binding.tanggalET.error = "Format Tanggal Salah"
                binding.simpanBT.setBackgroundColor(getColor(androidx.appcompat.R.color.primary_dark_material_light))
                binding.simpanBT.isClickable = false
            }
        }
        binding.simpanBT.setOnClickListener {
            recordToDatabase()
        }
        loginViewModel.currentNik.observe(this, Observer {
            binding.nikET.setText(it)
        })
        loginViewModel.currentUser.observe(this, Observer {
            binding.namaET.setText(it)
        })

        binding.tanggalET.setText(getCurrentDate())
    }

    private fun recordToDatabase() {
        val nik = binding.nikET.text.toString()
        val nama = binding.namaET.text.toString()
        val jumlah = binding.jumlahET.text.toString()
        val pemasok = binding.pemasokET.text.toString()
        val tanggal = binding.tanggalET.text.toString()

        val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH)
        val lastDate =
            if (recordViewModel.getDateRecord().isEmpty()) dateFormat.parse("0000/00/00") as Date
            else dateFormat.parse(recordViewModel.getDateRecord().first()) as Date

        val inputDate = dateFormat.parse(tanggal)


        if (inputCheck(nik, nama, jumlah, pemasok, tanggal)) {
            if (daysBetween(lastDate, inputDate!!) < 14) {
                //<editor-fold desc="Alert Dialog 1" defaultstate="collapsed">
                AlertDialog.Builder(this).setTitle("Tangal Bermasalah")
                    .setMessage("Tanggal input dengan catatan terakhir kurang dari 14 hari")
                    .setPositiveButton("Lanjut") { _, _ ->
                        //<editor-fold desc="Alert Dialog 2" defaultstate="collapsed">
                        AlertDialog.Builder(this).setTitle("Catat Barang")
                            .setMessage("Apakah anda yakin dengan pengisian catatan?")
                            .setPositiveButton("Ya") { _, _ ->
                                recordViewModel.recordData(
                                    RecordEntity(0, nik, nama, jumlah, pemasok, tanggal)
                                )
                                Toast.makeText(this, "Catatan Tersimpan", Toast.LENGTH_SHORT).show()
                                finish()
                            }.setNegativeButton("Kembali") { _, _ -> }.show()
                        //</editor-fold>
                    }.setNegativeButton("Kembali") { _, _ -> }.show()
                //</editor-fold>
            } else {
                AlertDialog.Builder(this).setTitle("Catat Barang")
                    .setMessage("Apakah anda yakin dengan pengisian catatan?")
                    .setPositiveButton("Ya") { _, _ ->
                        recordViewModel.recordData(
                            RecordEntity(0, nik, nama, jumlah, pemasok, tanggal)
                        )
                        Toast.makeText(this, "Catatan Tersimpan", Toast.LENGTH_SHORT).show()
                        finish()
                    }.setNegativeButton("Kembali") { _, _ -> }.show()
            }
        } else {
            Toast.makeText(this, "Catatan belum terisi lengkap", Toast.LENGTH_SHORT).show()
        }
        return

    }

    private fun isDateInputValid(): Boolean {
        // yyyy/mm/dd regex closest match to calendar
        return binding.tanggalET.text?.matches(("^\\d{4}\\/(0?[1-9]|1[012])\\/(0?[1-9]|[12][0-9]|3[01])\$").toRegex()) == true
    }

    private fun inputCheck(
        nik: String, nama: String, jumlah: String, pemasok: String, tanggal: String
    ): Boolean {
        return !(TextUtils.isEmpty(nik) || TextUtils.isEmpty(nama) || TextUtils.isEmpty(jumlah) || TextUtils.isEmpty(
            pemasok
        ) || TextUtils.isEmpty(tanggal))
    }

    private fun getCurrentDate(): String {
        val todayTime: Date = Calendar.getInstance().time
        val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH)
        return dateFormat.format(todayTime)
    }

    private fun daysBetween(d1: Date, d2: Date): Int {
        return ((d2.time - d1.time) / (1000 * 60 * 60 * 24)).toInt()
    }

}
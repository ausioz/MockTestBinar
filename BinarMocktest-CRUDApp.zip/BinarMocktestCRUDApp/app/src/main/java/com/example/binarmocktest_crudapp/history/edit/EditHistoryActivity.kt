package com.example.binarmocktest_crudapp.history.edit

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Parcelable
import android.text.TextUtils
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.ViewModelProvider
import com.example.binarmocktest_crudapp.R
import com.example.binarmocktest_crudapp.databinding.ActivityEditHistoryBinding
import com.example.binarmocktest_crudapp.di.ViewModelFactory
import com.example.binarmocktest_crudapp.model.RecordEntity
import com.example.binarmocktest_crudapp.viewmodel.RecordViewModel

class EditHistoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEditHistoryBinding
    private lateinit var recordViewModel: RecordViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recordViewModel = ViewModelProvider(this,ViewModelFactory(application))[RecordViewModel::class.java]

        val parcel = intent.parcelable<RecordEntity>("record")

        binding.nikET.setText(parcel?.nik)
        binding.namaET.setText(parcel?.nama)
        binding.jumlahET.setText(parcel?.jumlahBarang)
        binding.pemasokET.setText(parcel?.pemasok)
        binding.tanggalET.setText(parcel?.tanggal)

        binding.tanggalET.doAfterTextChanged {
            if (isDateInputValid()) {
                binding.simpanBT.setBackgroundColor(getColor(R.color.base))
                binding.simpanBT.isClickable = true
            } else {
                binding.tanggalET.error = "Format Tanggal Salah"
                binding.simpanBT.setBackgroundColor(getColor(androidx.appcompat.R.color.primary_dark_material_light))
                binding.simpanBT.isClickable = false
            }
        }

        binding.simpanBT.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Edit Catatan")
                .setMessage("Apakah anda yakin dengan edit catatan?")
                .setPositiveButton("Ya") { _, _ ->
                    updateToDatabase()
                    Toast.makeText(this, "Catatan Tersimpan", Toast.LENGTH_SHORT).show()
                    finish()
                }.setNegativeButton("Kembali") { _, _ -> }.show()
        }
    }
    private inline fun <reified T : Parcelable> Intent.parcelable(key: String): RecordEntity? = when {
        Build.VERSION.SDK_INT >= 33 -> getParcelableExtra(key, RecordEntity::class.java)
        else -> @Suppress("DEPRECATION") getParcelableExtra(key) as? RecordEntity
    }

    private fun updateToDatabase() {
        val parcel = intent.parcelable<RecordEntity>("record")
        val currentId = parcel?.id ?:0

        val nik = binding.nikET.text.toString()
        val nama = binding.namaET.text.toString()
        val jumlah = binding.jumlahET.text.toString()
        val pemasok = binding.pemasokET.text.toString()
        val tanggal = binding.tanggalET.text.toString()

        if (inputCheck(nik, nama, pemasok, jumlah, tanggal)){
            val updatedRecord = RecordEntity(currentId,nik,nama,jumlah,pemasok,tanggal)
            recordViewModel.updateRecord(updatedRecord)
        }
        else{
            Toast.makeText(this, "Catatan belum terisi lengkap", Toast.LENGTH_SHORT).show()
        }
    }


    private fun isDateInputValid(): Boolean {
        return binding.tanggalET.text?.matches(("^\\d{4}\\/(0?[1-9]|1[012])\\/(0?[1-9]|[12][0-9]|3[01])\$").toRegex()) == true
    }

    private fun inputCheck(
        nik: String, nama: String, jumlah: String,pemasok: String, tanggal: String
    ): Boolean {
        return !(TextUtils.isEmpty(nik) || TextUtils.isEmpty(nama)
                || TextUtils.isEmpty(jumlah) || TextUtils.isEmpty(pemasok)  ||
                TextUtils.isEmpty(tanggal))
    }
}


